from django.shortcuts import render
from django.http import HttpResponse
import librosa
import numpy as np
import pickle
import soundfile
import os, glob, pickle
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score

def extract_feature(file, mfcc=True, chroma=True, mel=True):
    X, sample_rate = librosa.load(file, res_type='kaiser_fast')
    result = np.array([])
    if mfcc:
        mfccs = np.mean(librosa.feature.mfcc(y=X, sr=sample_rate, n_mfcc=40).T, axis=0)
        result = np.hstack((result, mfccs))
    if chroma:
        stft = np.abs(librosa.stft(X))
        chroma = np.mean(librosa.feature.chroma_stft(S=stft, sr=sample_rate).T, axis=0)
        result = np.hstack((result, chroma))
    if mel:
        mel = np.mean(librosa.feature.melspectrogram(y=X, sr=sample_rate).T, axis=0)
        result = np.hstack((result, mel))
    return result



def home(request):
    if request.method=="POST":
        print("Request came\n\n")
        if "soundfile2" in request.FILES:
            model_file = 'model.pickle'
            with open(model_file, 'rb') as f:
                loaded_model = pickle.load(f)
            test_feature = extract_feature(request.FILES['soundfile2'], mfcc=True, chroma=True, mel=True)
            test_feature = test_feature.reshape(1, -1)  # Reshape the feature to match the input shape of the model
            predicted_emotion = loaded_model.predict(test_feature)[0]
            print("Predicted emotion:", predicted_emotion)
            return render(request,"speechemotion.html",context={"emotion_detect":1,"predicted_emotion":predicted_emotion})
            
    return render(request,"speechemotion.html")

